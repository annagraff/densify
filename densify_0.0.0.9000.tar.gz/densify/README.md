# densify

densify ist an R package for densifying sparse matrices 


# Installation (for users)

To install densify from CRAN, run the following code in R:

~~~~
install.packages("densify")
~~~~

# How to perform matrix densification with densify

For details on each function, refer to the help page (see below) and/or resort to the publication paper and vignette. 
~~~~
library("densify")

?flat_taxonomy_matrix
?densify_steps
?densify_score
?densify_prune
~~~~

## Contributing

For suggestions how `densify` could be improved or to report bugs, open an issue on GitHub. 

## Authors
- Anna Graff
- Marc Lischka
- Taras Zakharko
- Reinhard Furrer
- Balthasar Bickel
